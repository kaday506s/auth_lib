HOST_LDAP = 'http://127.0.0.1:8010'

TOKEN_LDAP = None

USER_MAP_LDAP = {
    'mail': 'email',
    'sAMAccountName': 'username',
    'givenName': 'first_name'
}

